package com.codefilms.springdemc.controller;


import java.util.List;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.codefilms.springdemc.entity.Insulin;
import com.codefilms.springdemc.service.InsulinService;

@Controller
@RequestMapping("/insulin")
public class InsulinController{
	
	
	
	
	// need to inject the insulin service
	@Autowired
	private InsulinService insulinService;
	
	@GetMapping("/list")
	public String listInsulins(Model theModel) {
		
		// get insulin from the dao;
		List<Insulin> theInsulins = insulinService.getInsulins();
		
		
		// add the insulin to the model;
		theModel.addAttribute("insulins", theInsulins);
		
		
		// add the insulin size to the model
		theModel.addAttribute("insulinSize", theInsulins.size());
		
		
				//console log get insulins
		try {
			System.out.println("inside listInsulins() ==>> size of list:"+theInsulins.size());
			for(Insulin tempInsulins: theInsulins)
			{
				System.out.println("inside listInsulins() ==>> insulins:"+tempInsulins.toString());
				System.out.println("\n");

			}
		}catch(Exception exe) {
			System.out.println(exe.getMessage());
		}
		
		
	
		return "list-insulins";
	}
	
	
	
	
	@GetMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		
		// create model attribute to bind form data
		Insulin theInsulin = new Insulin();
		
		theModel.addAttribute("insulin", theInsulin);
		
	
		return "insulin-record-form";
	}
	
	
	
	@PostMapping("/saveInsulin")
	public String saveInsulin(@ModelAttribute("insulin") Insulin theInsulin, HttpServletRequest request) {
		
		
		
		String action; //default action
		action = request.getParameter("form"); //get hidden fields
		
		System.out.println("inside saveInsulin ==> action:"+action); 
		
		if(action.equals("save"))
		insulinService.saveInsulin(theInsulin); 
		
		if(action.equals("update"))
		insulinService.updateInsulin(theInsulin); 
		

		
		return "redirect:/insulin/list";
	}
	
	
	
	
	
	
	@GetMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("insulinId") int theId,
			Model theModel) {
		
		
		// get the insulin shot from the database
		
		Insulin theInsulin = insulinService.getInsulin(theId);
		
		
		
		// parse the date returned to LocalDate
		//LocalDate tempDateShot = theInsulin.getDateShot();
		
		
		System.out.println("inside showFormForUpdate() ==> Insulin returned:" + theInsulin);
		
		
		
		
		// set insulin as a model attribute and prepopulate the form
		theModel.addAttribute("insulin", theInsulin);
		
		
		// send over to our form
		
		
		
		return "insulin-record-form";
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
