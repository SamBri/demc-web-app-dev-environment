package com.codefilms.springdemc.dao;

import java.util.List;

import com.codefilms.springdemc.entity.Insulin;

/**
 *  List of methods to expose CRUD operations on Insulin Table
 *  
 *  **/
public interface InsulinDAO {
	
	public List<Insulin> getInsulins();

	public void saveInsulin(Insulin theInsulin);

	public Insulin getInsulin(int theId);

 	public void updateInsulin(Insulin theInsulin);
	
	

	


}
