package com.codefilms.springdemc.dao;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.codefilms.springdemc.entity.Insulin;



@Repository
public class InsulinDAOImpl implements InsulinDAO {

	
	// need to inject the session factory
	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Override
	public List<Insulin> getInsulins() {
		
		
		//get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		// create query 
		Query<Insulin> query = currentSession.createNativeQuery("select id, date(date_shot) as date_shot,  time(time_shot) as time_shot, fbg_rbg, soluble_insulin, attendant from insulin", Insulin.class);
		
		// execute query
		List<Insulin> insulin = query.getResultList();
		

		// return the results
		return insulin;
	}


	@Override
	public void saveInsulin(Insulin theInsulin) {
		
		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		// save the customer...
		
		//create a query to insert into the db
		Query<Insulin> query = currentSession.createNativeQuery("insert into insulin(fbg_rbg, soluble_insulin,attendant) values (:fbg_rbg,:soluble_insulin,:attendant)", Insulin.class);
		query.setParameter("fbg_rbg",theInsulin.getFbgRBG());
		query.setParameter("soluble_insulin", theInsulin.getSolubleInsulin());
		query.setParameter("attendant", theInsulin.getAttendant());
				
		/*
		System.out.println("inside saveInsulin(): details  ==>"+theInsulin.getFbgRBG());
		System.out.println("inside saveInsulin(): details  ==>"+theInsulin.getSolubleInsulin());
		System.out.println("inside saveInsulin(): details  ==>"+theInsulin.getAttendant()); */

		
		
		 //execute query
		 int executed = query.executeUpdate();
		System.out.println("executed update:" + executed);
		
		
		
		
		
	}
	

	
	
	
	


	@Override
	public Insulin getInsulin(int theId) {
		
		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		
		// now retrieve/ read from database using the primary key
		Insulin theInsulin = currentSession.get(Insulin.class, theId);
		
		
		
		return theInsulin;
	}


	@Override
	public void updateInsulin(Insulin theInsulin) {
			
		// get the current hibernate session 
			Session currentSession = sessionFactory.getCurrentSession();
			
			
		     //execute query 
			//create a query to insert into the db
			Query<Insulin> query = currentSession.createNativeQuery("update insulin set fbg_rbg = :fbg_rbg, soluble_insulin = :soluble_insulin, attendant = :attendant where id = :id", Insulin.class);
			query.setParameter("fbg_rbg",theInsulin.getFbgRBG());
			query.setParameter("soluble_insulin", theInsulin.getSolubleInsulin());
			query.setParameter("attendant", theInsulin.getAttendant());
			query.setParameter("id",theInsulin.getId());
			
			query.executeUpdate();
		}

		
	


	

	
	
	
	
	
	
	
	

}
