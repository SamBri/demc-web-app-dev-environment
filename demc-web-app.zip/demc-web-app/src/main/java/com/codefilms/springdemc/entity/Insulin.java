package com.codefilms.springdemc.entity;


import java.sql.Date;

import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The Insulin class maps to the insulin Table
 * 
 * 
 * */
@Entity
@Table(name="insulin")
/*@NamedNativeQuery(
name="get_insulins", 
query="select id, date(date_shot) as date_shot,  time(time_shot) as time_shot, fbg_rbg, soluble_insulin, attendant from insulin")
*/
public class Insulin {

	
	/**
	 * An integer to keep the distinct insulin records Created.
	 * 
	 * */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id") 
	private int id;
	
	/**
	 *  A Date to keep the date insulin was shot 
	 *  
	 */
	@Column(name="date_shot")
	private Date dateShot; 
	
	


	/**
	 * 
	 *  A Time to keep the time insulin was shot
	 */
	@Column(name="time_shot")
	private Time timeShot;
	
	/**
	 * A String to keep the ratio of fasting blood glucose(FBG) to random blood glucose(RBG)
	 * */
	@Column(name="fbg_rbg")
	private String fbgRBG; 
	
	/**
	 * A String to keep the dosage of insulin shot
	 */
	@Column(name="soluble_insulin")
	private String solubleInsulin; 
	
	/**
	 * A String to keep the name of the attendant
	 * */
	@Column(name="attendant")
	private String attendant;

	public Insulin() {
	
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDateShot() {
		return dateShot;
	}

	public void setDateShot(Date dateShot) {
		this.dateShot = dateShot;
	}

	public Time getTimeShot() {
		return timeShot;
	}

	public void setTimeShot(Time timeShot) {
		this.timeShot = timeShot;
	}

	public String getFbgRBG() {
		return fbgRBG;
	}

	public void setFbgRBG(String fbgRBG) {
		this.fbgRBG = fbgRBG;
	}

	public String getSolubleInsulin() {
		return solubleInsulin;
	}

	public void setSolubleInsulin(String solubleInsulin) {
		this.solubleInsulin = solubleInsulin;
	}

	public String getAttendant() {
		return attendant;
	}

	public void setAttendant(String attendant) {
		this.attendant = attendant;
	}

	@Override
	public String toString() {
		return "Insulin [id=" + id + ", dateShot=" + dateShot + ", timeShot=" + timeShot + ", fbgRBG=" + fbgRBG
				+ ", solubleInsulin=" + solubleInsulin + ", attendant=" + attendant + "]";
	}
	
	
	
	
	
	
	
	
	
	/*public Insulin() {
	
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	public Date getDateShot() {
		return dateShot;
	}

	public void setDateShot(Date dateShot) {
		this.dateShot = dateShot;
	}
	

	public LocalDate getDateShot() throws ParseException {
	return LocalDate.parse(dateShot);
	}
	
	

	public void setDateShot(String dateShot) {
		this.dateShot = dateShot;
	} 

	public Time getTimeShot() {
		return timeShot;
	}

	public void setTimeShot(Time timeShot) {
		this.timeShot = timeShot;
	}

	public String getFbgRBG() {
		return fbgRBG;
	}

	public void setFbgRBG(String fbgRBG) {
		this.fbgRBG = fbgRBG;
	}

	public String getSolubleInsulin() {
		return solubleInsulin;
	}

	public void setSolubleInsulin(String solubleInsulin) {
		this.solubleInsulin = solubleInsulin;
	}

	public String getAttendant() {
		return attendant;
	}

	public void setAttendant(String attendant) {
		this.attendant = attendant;
	}

	
	public String toString() {
		return "Insulin [id=" + id + ", dateShot=" + dateShot.toString() + ", timeShot=" + timeShot.toString() + ", fbgRBG=" + fbgRBG
				+ ", solubleInsulin=" + solubleInsulin + ", attendant=" + attendant + "]";
	} */
	
	
	
	
	
	
	
	
	
	
	
	
	
}
