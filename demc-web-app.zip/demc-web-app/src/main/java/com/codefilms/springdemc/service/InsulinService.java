package com.codefilms.springdemc.service;

import java.util.List;

import com.codefilms.springdemc.entity.Insulin;

public interface InsulinService {
	
	public List<Insulin> getInsulins();

	public void saveInsulin(Insulin theInsulin);

	public Insulin getInsulin(int theId);


	public void updateInsulin(Insulin theInsulin);

	

}
