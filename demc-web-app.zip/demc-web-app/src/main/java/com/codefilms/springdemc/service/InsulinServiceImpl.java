package com.codefilms.springdemc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.codefilms.springdemc.dao.InsulinDAO;
import com.codefilms.springdemc.entity.Insulin;


@Service
public class InsulinServiceImpl implements InsulinService {

	
	
	// need to inject the insulin dao
	@Autowired
	private InsulinDAO insulinDAO;
	
	
	@Override
	@Transactional
	public List<Insulin> getInsulins() {			
		return insulinDAO.getInsulins();				
	}


	@Override
	@Transactional
	public void saveInsulin(Insulin theInsulin) {
		insulinDAO.saveInsulin(theInsulin);
	}

	
	

	@Override
	@Transactional
	public Insulin getInsulin(int theId) {
		// TODO Auto-generated method stub
		return insulinDAO.getInsulin(theId);
	}


	@Override
	public void updateInsulin(Insulin theInsulin) {

			insulinDAO.updateInsulin(theInsulin);
		}
		
	





	
	
	

}
